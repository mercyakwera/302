 CREATE DATABASE HOUSING_SYSTEM;
  USE HOUSING_SYSTEM;
   CREATE TABLE User (
        Id VARCHAR(15) PRIMARY KEY,
         Name VARCHAR(25),
         Email VARCHAR(25),
         ContactNumber VARCHAR(20),
         Role VARCHAR(30),
         CreatedDate DATE
     );
     
      CREATE TABLE Housing (
         Id VARCHAR(15) PRIMARY KEY,
         Type VARCHAR(50),
         Location VARCHAR(25),
         Size DECIMAL(10, 2),
         RentAmount DECIMAL(10, 2)
     );
      CREATE TABLE Applicant (
        Id VARCHAR(25) PRIMARY KEY,
         UserId VARCHAR(15),
         FirstName VARCHAR(25),
	     LastName VARCHAR(25),
         DateOfBirth DATE,
         ApplicationId VARCHAR(25),
         Income DECIMAL(10, 2),
         FamilySize INT,
         EmploymentStatus VARCHAR(50));
         
          CREATE TABLE Application (
         Id VARCHAR(15) PRIMARY KEY,
         ApplicantId VARCHAR(15),
         UnitId VARCHAR(15),
         ApplicationDate DATETIME,
         Status VARCHAR(30),
         FOREIGN KEY (ApplicantId) REFERENCES Applicant(Id),
         FOREIGN KEY (UnitId) REFERENCES Housing(Id)
    );
     CREATE TABLE Payment (
         Id VARCHAR(15) PRIMARY KEY,
         LeaseId VARCHAR(15),
         PaymentDate DATETIME,
         Amount DECIMAL(10, 2),
         PaymentMethod VARCHAR(30),
         FOREIGN KEY (LeaseId) REFERENCES Lease(Id)
    );
    CREATE TABLE Lease (
         Id VARCHAR(25) PRIMARY KEY,
         ApplicationId VARCHAR(15),
         StartDate DATETIME,
         EndDate DATETIME,
         MonthlyRent DECIMAL(10, 2),
         LeaseTerms TEXT,
         LeaseStatus VARCHAR(50),
         FOREIGN KEY (ApplicationId) REFERENCES Application(Id)
    );